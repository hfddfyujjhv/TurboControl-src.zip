package com.turboc.control.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.turboc.control.core.PowerMode
import com.turboc.control.core.TurboEngine
import com.turboc.control.root.RootShell
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class TurboViewModel : ViewModel() {

    private val _isRoot = MutableStateFlow(false)
    val isRoot: StateFlow<Boolean> = _isRoot.asStateFlow()

    private val _uperfInstalled = MutableStateFlow(false)
    val uperfInstalled: StateFlow<Boolean> = _uperfInstalled.asStateFlow()

    private val _currentMode = MutableStateFlow<PowerMode?>(null)
    val currentMode: StateFlow<PowerMode?> = _currentMode.asStateFlow()

    private val _refreshOn = MutableStateFlow(false)
    val refreshOn: StateFlow<Boolean> = _refreshOn.asStateFlow()

    private val _schedOn = MutableStateFlow(false)
    val schedOn: StateFlow<Boolean> = _schedOn.asStateFlow()

    private val _currentHz = MutableStateFlow(60)
    val currentHz: StateFlow<Int> = _currentHz.asStateFlow()

    private val _socName = MutableStateFlow("unknown")
    val socName: StateFlow<String> = _socName.asStateFlow()

    // FPS 悬浮窗开关（公开，供 MainActivity 绑定）
    val fpsOverlayOn = MutableStateFlow(false)

    fun refresh() {
        viewModelScope.launch {
            _isRoot.value = RootShell.isRoot()
            _uperfInstalled.value = TurboEngine.isUperfInstalled()
            _currentMode.value = TurboEngine.currentMode()
            _schedOn.value = TurboEngine.isTakeoverActive()
            _socName.value = TurboEngine.getSoCName()
            _currentHz.value = TurboEngine.getCurrentRefreshRate()
            _refreshOn.value = _currentHz.value >= 144
        }
    }

    fun setRefreshRate(on: Boolean) {
        viewModelScope.launch {
            val target = if (on) 144 else 60
            if (TurboEngine.setRefreshRate(target)) {
                _refreshOn.value = on
            }
            delay(500)
            _currentHz.value = TurboEngine.getCurrentRefreshRate()
        }
    }

    fun enableSchedTakeover() {
        viewModelScope.launch {
            if (TurboEngine.enableSchedulingTakeover()) _schedOn.value = true
        }
    }

    fun disableSchedTakeover() {
        viewModelScope.launch {
            TurboEngine.disableSchedulingTakeover()
            _schedOn.value = false
        }
    }

    fun setMode(mode: PowerMode) {
        viewModelScope.launch {
            TurboEngine.setMode(mode)
            delay(300)
            _currentMode.value = TurboEngine.currentMode()
        }
    }
}
