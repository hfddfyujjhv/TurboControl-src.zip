# Turbo Control —— Scene 的替代品

Scene 核心功能的复刻：**刷新率管理 + 调度接管 + Uperf 模式控制 + FPS 悬浮窗**。
不需要 Scene，Uperf 模块只是底层执行器，本 App 直接管一切。

## 功能

| 开关 | 作用 |
|---|---|
| 刷新率管理 | 一键切换 144Hz ↔ 60Hz（替代 Scene 的「刷新率管理」） |
| 调度接管 | 停止 MIUI perfd / miuibooster / thermal，锁 GPU 最高档，锁 CPU 最低频（替代 Scene 的「调度开关」） |
| Uperf 模式 | 选省电/均衡/性能/极速/狂暴，写入 cur_powermode.txt |
| FPS 悬浮窗 | 游戏内浮窗显示实时 FPS 和当前模式，可拖动 |

## 前置条件

1. 已刷入 **Uperf Game Turbo X** 模块（底层执行器）
2. 已 root（Magisk / KernelSU / APatch）
3. 悬浮窗需授权「显示在其他应用上层」

## 与 Scene 的对比

| 功能 | Scene | Turbo Control |
|---|---|---|
| 刷新率管理 | ✅ | ✅ |
| 调度接管 | ✅ | ✅（更彻底） |
| Uperf 模式选择 | ✅ | ✅ |
| per-app 配置 | ❌ | ❌（暂时不做） |
| FPS 悬浮窗 | 有（复杂） | ✅（简洁版） |
| 体积 | ~10MB | ~5MB |

## 编译

需要 Android Studio（JDK 17 + Android Gradle Plugin 8.4）。

```bash
./gradlew assembleDebug
# 产物：app/build/outputs/apk/debug/app-debug.apk
```

或通过 GitHub Actions 自动编译（见 `.github/workflows/build.yml`）。

## 目录结构

```
app/src/main/java/com/turboc/control/
├── MainActivity.kt       # 入口，悬浮窗权限处理
├── root/RootShell.kt     # root shell 封装（libsu）
├── core/TurboEngine.kt   # 核心逻辑：刷新率/GPU/调度/Uperf
├── ui/
│   ├── TurboScreen.kt    # 主界面（4 个开关卡片）
│   └── TurboViewModel.kt # 状态管理
└── overlay/FpsOverlayService.kt  # FPS 悬浮窗服务
```

## 工作原理

- **刷新率**：通过 `svc power set-refresh-rate` 和 DRM sysfs 节点切换
- **调度接管**：杀掉 perfd/miuibooster/thermal-engine，锁 kgsl GPU pwrlevel 到最高，devfreq GPU min_freq = max_freq
- **Uperf 模式**：解析 `/data/powercfg.json` 获取 entry 路径，执行 `sh <entry> <mode>`
- **FPS**：读 SurfaceFlinger dumpsys
